# SymptoMap Doctor Station - Complete Deployment Guide

## 🚀 Quick Start

This guide will help you deploy the SymptoMap Doctor Station application and make it accessible via a shareable URL.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Local Development Setup](#local-development-setup)
3. [Production Deployment](#production-deployment)
4. [Configuration](#configuration)
5. [Usage Guide](#usage-guide)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Software
- **Python 3.11+** (for backend)
- **Modern web browser** (Chrome, Firefox, Safari, Edge)
- **Docker** (optional, for containerized deployment)
- **Git** (for version control)

### Optional Tools
- **PostgreSQL** (for production database)
- **Nginx** (for production web server)
- **SSL Certificate** (for HTTPS)

---

## 🏠 Local Development Setup

### Step 1: Clone/Download the Project

```bash
cd symptomap-doctor-station
```

### Step 2: Set Up Backend

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run backend server
python main.py
```

Backend will be running at: `http://localhost:8000`

### Step 3: Set Up Frontend

```bash
# Simply open the frontend/index.html file in a browser
# OR use a simple HTTP server

# Option 1: Python HTTP server
cd frontend
python -m http.server 3000

# Option 2: Node.js HTTP server
npx serve frontend -p 3000
```

Frontend will be accessible at: `http://localhost:3000`

### Step 4: Test the Application

1. Open browser to `http://localhost:3000`
2. Login with password: `Doctor@SymptoMap2025`
3. Try submitting an outbreak or creating an alert

✅ **You're ready for development!**

---

## 🌐 Production Deployment

### Option 1: Deploy to Render.com (Recommended - FREE)

Render.com offers free hosting perfect for this application.

#### Step 1: Create Render Account
1. Go to https://render.com
2. Sign up with GitHub/GitLab/Email

#### Step 2: Deploy Backend

1. Click "New +" → "Web Service"
2. Connect your repository
3. Configure:
   - **Name**: symptomap-backend
   - **Environment**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Plan**: Free

4. Add Environment Variables:
   ```
   SECRET_KEY=symptomap-doctor-secret-key-2025
   DOCTOR_PASSWORD=Doctor@SymptoMap2025
   DATABASE_PATH=/var/data/symptomap.db
   ```

5. Click "Create Web Service"

#### Step 3: Deploy Frontend

1. Click "New +" → "Static Site"
2. Connect your repository
3. Configure:
   - **Name**: symptomap-frontend
   - **Publish Directory**: frontend
   - **Plan**: Free

4. Update `frontend/index.html`:
   ```javascript
   const API_BASE_URL = 'https://symptomap-backend.onrender.com';
   ```

5. Click "Create Static Site"

#### Step 4: Get Your Shareable URL

Your application will be available at:
- **Frontend**: `https://symptomap-frontend.onrender.com`
- **Backend API**: `https://symptomap-backend.onrender.com`

✅ **Share the frontend URL with doctors!**

---

### Option 2: Deploy with Docker

#### Step 1: Build and Run

```bash
# From project root
cd deployment

# Build and start containers
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

#### Step 2: Access Application

- Frontend: `http://localhost`
- Backend: `http://localhost:8000`

#### Step 3: Deploy to Cloud

Upload your Docker images to:
- **AWS**: ECR + ECS/Fargate
- **Google Cloud**: Container Registry + Cloud Run
- **Azure**: Container Registry + Container Instances
- **DigitalOcean**: Container Registry + App Platform

---

### Option 3: Deploy to Railway.app

Railway offers simple deployment with automatic SSL.

1. Go to https://railway.app
2. Sign up and create new project
3. Click "New" → "Deploy from GitHub repo"
4. Select your repository
5. Railway auto-detects Python and deploys
6. Set environment variables
7. Get your railway.app URL

---

### Option 4: Deploy to Vercel/Netlify (Frontend only)

#### Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy frontend
cd frontend
vercel
```

#### Netlify

1. Go to https://netlify.com
2. Drag and drop `frontend` folder
3. Get instant URL

**Note**: You'll need to deploy backend separately (Render/Railway/Heroku)

---

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the backend directory:

```env
# Backend Configuration
SECRET_KEY=your-super-secret-key-change-this
DOCTOR_PASSWORD=YourCustomPassword123!
DATABASE_PATH=/path/to/symptomap.db

# Optional
JWT_EXPIRATION_HOURS=24
LOG_LEVEL=INFO
PORT=8000
```

### Frontend API Configuration

Update `frontend/index.html`:

```javascript
// For production
const API_BASE_URL = 'https://your-backend-domain.com';

// For development
const API_BASE_URL = 'http://localhost:8000';
```

### Custom Domain Setup

#### For Render.com

1. Go to dashboard → Settings → Custom Domains
2. Add your domain (e.g., `symptomap.com`)
3. Update DNS records as instructed
4. Render automatically provisions SSL

#### For Railway.app

1. Settings → Custom Domain
2. Add domain and update DNS
3. SSL auto-configured

---

## 📖 Usage Guide

### For Administrators

#### 1. Access Doctor Station
- Share URL: `https://your-domain.com/doctor`
- Password: `Doctor@SymptoMap2025`

#### 2. Submit Outbreak Data
1. Login to doctor station
2. Click "Submit Outbreak" tab
3. Fill in all required fields:
   - Disease type
   - Patient count
   - Severity level
   - Date reported
4. Click on map to mark location
5. Add location details (hospital, city, state)
6. Add description and symptoms
7. Click "Submit Outbreak Data"

#### 3. Create Health Alert
1. Click "Create Alert" tab
2. Select alert type (Critical/Warning/Info)
3. Enter title and message
4. Mark location on map
5. Set affected radius
6. Add action required
7. Click "Create Alert"

#### 4. View Submissions
- Click "View Submissions" tab
- See all outbreaks and alerts
- Delete items if needed
- View statistics

### For Doctors

#### Login Process
1. Navigate to doctor station URL
2. See password displayed on login screen
3. Enter password: `Doctor@SymptoMap2025`
4. Click "Login to Doctor Station"

#### Data Submission
- All fields marked with * are required
- Use map to pinpoint exact location
- Quick location buttons for major cities
- Forms validate data before submission
- Success/error messages shown immediately

---

## 🔐 Security Best Practices

### 1. Change Default Password

Update password in backend:

```python
# backend/main.py
DOCTOR_PASSWORD = "YourNewSecurePassword123!"
```

Also update in environment variables.

### 2. Enable HTTPS

Always use HTTPS in production:
- Render/Railway provide free SSL
- For custom hosting, use Let's Encrypt
- Update CORS origins to HTTPS URLs

### 3. Database Backups

Run automated backups:

```bash
# Manual backup
python scripts/backup_database.py backup

# Schedule with cron (Linux/Mac)
0 */6 * * * cd /path/to/project && python scripts/backup_database.py backup

# Schedule with Task Scheduler (Windows)
# Create task to run backup_database.py every 6 hours
```

### 4. Rate Limiting

Backend has built-in rate limiting:
- 5 failed login attempts = 15-minute lockout
- Tracks by IP address
- Prevents brute force attacks

---

## 🛠️ Maintenance

### Database Management

#### View Database
```bash
sqlite3 symptomap.db
.tables
SELECT * FROM doctor_outbreaks LIMIT 10;
.exit
```

#### Backup Database
```bash
python scripts/backup_database.py backup
```

#### List Backups
```bash
python scripts/backup_database.py list
```

#### Restore Database
```bash
python scripts/backup_database.py restore backups/symptomap_backup_20250130_120000.db
```

### Data Import

#### Generate Sample CSVs
```bash
python scripts/import_data.py sample-outbreak
python scripts/import_data.py sample-alert
```

#### Import Data
```bash
python scripts/import_data.py outbreaks data/outbreaks.csv
python scripts/import_data.py alerts data/alerts.csv
```

---

## 🐛 Troubleshooting

### Backend Won't Start

**Error**: `Address already in use`
```bash
# Find and kill process on port 8000
# Linux/Mac:
lsof -ti:8000 | xargs kill -9

# Windows:
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

**Error**: `Module not found`
```bash
pip install -r requirements.txt
```

### Frontend Can't Connect to Backend

1. Check backend is running: `curl http://localhost:8000/health`
2. Verify API_BASE_URL in frontend code
3. Check CORS settings in backend
4. Check browser console for errors

### Database Errors

**Error**: `Database is locked`
```bash
# Close all connections
# Restart backend server
python main.py
```

**Error**: `Table doesn't exist`
```bash
# Delete and recreate database
rm symptomap.db
python main.py  # Auto-creates tables
```

### Login Issues

**Can't login**:
1. Verify password is correct
2. Check browser console for errors
3. Test backend directly:
   ```bash
   curl -X POST http://localhost:8000/api/v1/doctor/login \
     -H "Content-Type: application/json" \
     -d '{"password":"Doctor@SymptoMap2025"}'
   ```

### Map Not Loading

1. Check internet connection (needs OpenStreetMap access)
2. Check browser console for errors
3. Verify Leaflet library is loaded
4. Try different browser

---

## 📊 Monitoring

### Health Check

```bash
# Check if backend is running
curl http://localhost:8000/health

# Expected response:
# {"status":"healthy","database":"connected","timestamp":"..."}
```

### View Logs

```bash
# Docker logs
docker-compose logs -f backend

# Local logs (stdout)
# Check terminal where backend is running
```

### Database Stats

```bash
# Connect to database
sqlite3 symptomap.db

# Count records
SELECT COUNT(*) FROM doctor_outbreaks;
SELECT COUNT(*) FROM doctor_alerts;

# Today's submissions
SELECT COUNT(*) FROM doctor_outbreaks 
WHERE DATE(submitted_at) = DATE('now');
```

---

## 🔗 API Endpoints Reference

### Authentication
- `POST /api/v1/doctor/login` - Login and get token
- `POST /api/v1/doctor/verify-token` - Verify token validity

### Outbreak Management
- `POST /api/v1/doctor/outbreak` - Submit outbreak data
- `GET /api/v1/doctor/outbreaks` - List all outbreaks
- `GET /api/v1/doctor/outbreak/{id}` - Get specific outbreak
- `DELETE /api/v1/doctor/outbreak/{id}` - Delete outbreak

### Alert Management
- `POST /api/v1/doctor/alert` - Create alert
- `GET /api/v1/doctor/alerts` - List all alerts
- `DELETE /api/v1/doctor/alert/{id}` - Delete alert

### Public Endpoints (No auth required)
- `GET /api/v1/outbreaks/public` - Get public outbreak data
- `GET /api/v1/alerts/public` - Get active public alerts
- `GET /api/v1/stats/public` - Get statistics
- `GET /health` - Health check

---

## 📧 Support

For issues or questions:
1. Check this documentation
2. Review error messages in browser console
3. Check backend logs
4. Contact system administrator

---

## 🎯 Next Steps

After successful deployment:

1. ✅ Share URL with authorized doctors
2. ✅ Set up automated database backups
3. ✅ Configure monitoring/alerting
4. ✅ Train doctors on system usage
5. ✅ Test all features thoroughly
6. ✅ Create user documentation
7. ✅ Set up analytics (optional)

---

## 📝 Changelog

### Version 1.0.0 (2025-01-30)
- Initial release
- Doctor authentication system
- Outbreak submission with map picker
- Alert management system
- Real-time dashboard
- Database backup utilities
- CSV import/export
- Complete documentation

---

**End of Deployment Guide**

For the latest updates, visit the project repository.
