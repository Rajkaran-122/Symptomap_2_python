#!/usr/bin/env python3
"""
Data Import Script for SymptoMap Doctor Station
Import outbreak and alert data from CSV files
"""

import sqlite3
import csv
import os
from datetime import datetime

DATABASE_PATH = os.getenv('DATABASE_PATH', 'symptomap.db')

def import_outbreaks_from_csv(csv_file):
    """Import outbreak data from CSV file"""
    
    if not os.path.exists(csv_file):
        print(f"❌ CSV file not found: {csv_file}")
        return False
    
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        imported = 0
        errors = 0
        
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            for row_num, row in enumerate(reader, start=1):
                try:
                    cursor.execute("""
                        INSERT INTO doctor_outbreaks 
                        (disease_type, patient_count, severity, latitude, longitude,
                         location_name, city, state, country, description, symptoms,
                         treatment_status, date_reported, submitted_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        row['disease_type'],
                        int(row['patient_count']),
                        row['severity'].lower(),
                        float(row['latitude']),
                        float(row['longitude']),
                        row.get('location_name', ''),
                        row.get('city', ''),
                        row.get('state', ''),
                        row.get('country', 'India'),
                        row.get('description', ''),
                        row.get('symptoms', ''),
                        row.get('treatment_status', ''),
                        row['date_reported'],
                        'bulk_import'
                    ))
                    imported += 1
                except Exception as e:
                    print(f"⚠️  Error on row {row_num}: {str(e)}")
                    errors += 1
        
        conn.commit()
        conn.close()
        
        print(f"\n✅ Import complete!")
        print(f"   📊 Imported: {imported} records")
        if errors > 0:
            print(f"   ⚠️  Errors: {errors} records")
        
        return True
    
    except Exception as e:
        print(f"❌ Import failed: {str(e)}")
        return False

def import_alerts_from_csv(csv_file):
    """Import alert data from CSV file"""
    
    if not os.path.exists(csv_file):
        print(f"❌ CSV file not found: {csv_file}")
        return False
    
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        imported = 0
        errors = 0
        
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            for row_num, row in enumerate(reader, start=1):
                try:
                    # Calculate expiry date
                    expiry_hours = int(row.get('expiry_hours', 168))
                    expiry_date = datetime.now()
                    from datetime import timedelta
                    expiry_date = expiry_date + timedelta(hours=expiry_hours)
                    
                    cursor.execute("""
                        INSERT INTO doctor_alerts 
                        (alert_type, title, message, affected_area, latitude, longitude,
                         radius_km, priority, category, contact_info, action_required,
                         expiry_date, created_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        row['alert_type'].lower(),
                        row['title'],
                        row['message'],
                        row['affected_area'],
                        float(row.get('latitude', 0)) if row.get('latitude') else None,
                        float(row.get('longitude', 0)) if row.get('longitude') else None,
                        float(row.get('radius_km', 10)),
                        int(row.get('priority', 2)),
                        row.get('category', 'outbreak'),
                        row.get('contact_info', ''),
                        row.get('action_required', ''),
                        expiry_date.isoformat(),
                        'bulk_import'
                    ))
                    imported += 1
                except Exception as e:
                    print(f"⚠️  Error on row {row_num}: {str(e)}")
                    errors += 1
        
        conn.commit()
        conn.close()
        
        print(f"\n✅ Import complete!")
        print(f"   📊 Imported: {imported} alerts")
        if errors > 0:
            print(f"   ⚠️  Errors: {errors} alerts")
        
        return True
    
    except Exception as e:
        print(f"❌ Import failed: {str(e)}")
        return False

def generate_sample_outbreaks_csv():
    """Generate sample CSV template for outbreaks"""
    
    sample_data = [
        {
            'disease_type': 'Dengue',
            'patient_count': 45,
            'severity': 'moderate',
            'latitude': 26.9124,
            'longitude': 75.7873,
            'location_name': 'SMS Hospital',
            'city': 'Jaipur',
            'state': 'Rajasthan',
            'country': 'India',
            'description': 'Seasonal outbreak during monsoon',
            'symptoms': 'Fever, Headache, Joint pain',
            'treatment_status': 'Under treatment',
            'date_reported': '2025-01-15'
        },
        {
            'disease_type': 'Malaria',
            'patient_count': 23,
            'severity': 'moderate',
            'latitude': 28.7041,
            'longitude': 77.1025,
            'location_name': 'AIIMS Delhi',
            'city': 'Delhi',
            'state': 'Delhi',
            'country': 'India',
            'description': 'Monsoon-related cases',
            'symptoms': 'High fever, Chills, Sweating',
            'treatment_status': 'Active treatment',
            'date_reported': '2025-01-16'
        }
    ]
    
    filename = 'sample_outbreaks.csv'
    
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        fieldnames = sample_data[0].keys()
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sample_data)
    
    print(f"✅ Sample outbreak CSV created: {filename}")
    return filename

def generate_sample_alerts_csv():
    """Generate sample CSV template for alerts"""
    
    sample_data = [
        {
            'alert_type': 'warning',
            'title': 'Dengue Alert - Mumbai Region',
            'message': 'Increased dengue cases reported. Take preventive measures.',
            'affected_area': 'Mumbai, Maharashtra',
            'latitude': 19.0760,
            'longitude': 72.8777,
            'radius_km': 50,
            'priority': 2,
            'category': 'outbreak',
            'contact_info': 'Helpline: 1800-XXX-XXXX',
            'action_required': 'Avoid water stagnation, use mosquito repellent',
            'expiry_hours': 168
        },
        {
            'alert_type': 'critical',
            'title': 'COVID-19 Cluster - Bangalore',
            'message': 'New COVID-19 cluster identified. Enhanced testing recommended.',
            'affected_area': 'Bangalore, Karnataka',
            'latitude': 12.9716,
            'longitude': 77.5946,
            'radius_km': 20,
            'priority': 1,
            'category': 'outbreak',
            'contact_info': 'Emergency: 108',
            'action_required': 'Get tested if symptoms present, wear masks',
            'expiry_hours': 72
        }
    ]
    
    filename = 'sample_alerts.csv'
    
    with open(filename, 'w', newline='', encoding='utf-8') as f:
        fieldnames = sample_data[0].keys()
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sample_data)
    
    print(f"✅ Sample alert CSV created: {filename}")
    return filename

if __name__ == "__main__":
    import sys
    
    print("=" * 60)
    print("🏥 SymptoMap Data Import Utility")
    print("=" * 60)
    
    if len(sys.argv) < 2:
        print("\nUsage:")
        print("  python import_data.py outbreaks <csv_file>  - Import outbreaks")
        print("  python import_data.py alerts <csv_file>     - Import alerts")
        print("  python import_data.py sample-outbreak       - Generate sample outbreak CSV")
        print("  python import_data.py sample-alert          - Generate sample alert CSV")
    else:
        command = sys.argv[1].lower()
        
        if command == 'outbreaks':
            if len(sys.argv) < 3:
                print("❌ Please provide CSV file path")
            else:
                import_outbreaks_from_csv(sys.argv[2])
        
        elif command == 'alerts':
            if len(sys.argv) < 3:
                print("❌ Please provide CSV file path")
            else:
                import_alerts_from_csv(sys.argv[2])
        
        elif command == 'sample-outbreak':
            generate_sample_outbreaks_csv()
        
        elif command == 'sample-alert':
            generate_sample_alerts_csv()
        
        else:
            print(f"❌ Unknown command: {command}")
    
    print("=" * 60)
