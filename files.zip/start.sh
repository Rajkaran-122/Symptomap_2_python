#!/bin/bash

# SymptoMap Doctor Station - Quick Start Script
# This script sets up and runs the application locally

set -e

echo "=================================================="
echo "🏥 SymptoMap Doctor Station - Quick Start"
echo "=================================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "Please install Python 3.11 or higher"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
echo "✅ Found Python $PYTHON_VERSION"
echo ""

# Create data directory
echo "📁 Creating data directory..."
mkdir -p data
mkdir -p backups

# Setup backend
echo "📦 Setting up backend..."
cd backend

if [ ! -d "venv" ]; then
    echo "  Creating virtual environment..."
    python3 -m venv venv
fi

echo "  Activating virtual environment..."
source venv/bin/activate || . venv/Scripts/activate

echo "  Installing dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

echo "✅ Backend setup complete"
echo ""

# Start backend in background
echo "🚀 Starting backend server..."
python main.py &
BACKEND_PID=$!
echo "  Backend PID: $BACKEND_PID"
echo "  Backend URL: http://localhost:8000"

# Wait for backend to start
echo "  Waiting for backend to be ready..."
sleep 3

# Check if backend is running
if curl -s http://localhost:8000/health > /dev/null 2>&1; then
    echo "✅ Backend is running"
else
    echo "⚠️  Backend may not be ready yet"
fi

cd ..

echo ""
echo "=================================================="
echo "✅ Setup Complete!"
echo "=================================================="
echo ""
echo "📍 Frontend: Open frontend/index.html in your browser"
echo "   OR run: python -m http.server 3000"
echo ""
echo "🔐 Login Credentials:"
echo "   Password: Doctor@SymptoMap2025"
echo ""
echo "📖 Documentation:"
echo "   - User Manual: docs/USER_MANUAL.md"
echo "   - Deployment Guide: docs/DEPLOYMENT_GUIDE.md"
echo ""
echo "🛑 To stop the backend:"
echo "   kill $BACKEND_PID"
echo ""
echo "=================================================="

# Keep script running
echo "Press Ctrl+C to stop the backend server..."
wait $BACKEND_PID
