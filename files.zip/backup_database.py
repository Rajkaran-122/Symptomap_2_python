#!/usr/bin/env python3
"""
Database Backup Script for SymptoMap Doctor Station
Automatically backs up the database with timestamp
"""

import shutil
import os
from datetime import datetime
import glob

# Configuration
SOURCE_DB = os.getenv('DATABASE_PATH', 'symptomap.db')
BACKUP_DIR = 'backups'
RETENTION_DAYS = 30

def create_backup():
    """Create timestamped database backup"""
    # Create backup directory if it doesn't exist
    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)
        print(f"✅ Created backup directory: {BACKUP_DIR}")
    
    # Generate timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_file = f'{BACKUP_DIR}/symptomap_backup_{timestamp}.db'
    
    # Check if source database exists
    if not os.path.exists(SOURCE_DB):
        print(f"❌ Source database not found: {SOURCE_DB}")
        return False
    
    # Copy database
    try:
        shutil.copy2(SOURCE_DB, backup_file)
        file_size = os.path.getsize(backup_file) / 1024  # KB
        print(f"✅ Database backed up successfully")
        print(f"   📁 File: {backup_file}")
        print(f"   📊 Size: {file_size:.2f} KB")
        return True
    except Exception as e:
        print(f"❌ Backup failed: {str(e)}")
        return False

def cleanup_old_backups():
    """Remove backups older than retention period"""
    backup_files = glob.glob(f'{BACKUP_DIR}/symptomap_backup_*.db')
    backup_files.sort(reverse=True)
    
    # Keep only the most recent backups based on retention
    max_backups = RETENTION_DAYS * 4  # 4 backups per day (every 6 hours)
    
    if len(backup_files) > max_backups:
        old_backups = backup_files[max_backups:]
        for backup in old_backups:
            try:
                os.remove(backup)
                print(f"🗑️  Removed old backup: {backup}")
            except Exception as e:
                print(f"⚠️  Could not remove {backup}: {str(e)}")
        
        print(f"✅ Cleanup complete. Kept {max_backups} most recent backups")
    else:
        print(f"ℹ️  Total backups: {len(backup_files)} (within retention limit)")

def list_backups():
    """List all available backups"""
    backup_files = glob.glob(f'{BACKUP_DIR}/symptomap_backup_*.db')
    
    if not backup_files:
        print("ℹ️  No backups found")
        return
    
    print(f"\n📋 Available Backups ({len(backup_files)}):")
    print("-" * 60)
    
    for backup in sorted(backup_files, reverse=True):
        size = os.path.getsize(backup) / 1024
        mtime = datetime.fromtimestamp(os.path.getmtime(backup))
        print(f"  {os.path.basename(backup):<40} {size:>8.2f} KB  {mtime}")

def restore_backup(backup_file):
    """Restore database from backup"""
    if not os.path.exists(backup_file):
        print(f"❌ Backup file not found: {backup_file}")
        return False
    
    try:
        # Create a backup of current database before restoring
        if os.path.exists(SOURCE_DB):
            safety_backup = f'{SOURCE_DB}.before_restore'
            shutil.copy2(SOURCE_DB, safety_backup)
            print(f"🛡️  Safety backup created: {safety_backup}")
        
        # Restore from backup
        shutil.copy2(backup_file, SOURCE_DB)
        print(f"✅ Database restored from: {backup_file}")
        return True
    except Exception as e:
        print(f"❌ Restore failed: {str(e)}")
        return False

if __name__ == "__main__":
    import sys
    
    print("=" * 60)
    print("🏥 SymptoMap Database Backup Utility")
    print("=" * 60)
    
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'backup':
            create_backup()
            cleanup_old_backups()
        
        elif command == 'list':
            list_backups()
        
        elif command == 'restore':
            if len(sys.argv) < 3:
                print("❌ Usage: python backup_database.py restore <backup_file>")
            else:
                restore_backup(sys.argv[2])
        
        elif command == 'cleanup':
            cleanup_old_backups()
        
        else:
            print(f"❌ Unknown command: {command}")
            print("\nAvailable commands:")
            print("  backup  - Create new backup")
            print("  list    - List all backups")
            print("  restore - Restore from backup")
            print("  cleanup - Remove old backups")
    else:
        # Default action: create backup
        create_backup()
        cleanup_old_backups()
    
    print("=" * 60)
