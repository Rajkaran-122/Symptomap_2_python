# 🏥 SymptoMap Doctor Station

> **Secure web portal for healthcare professionals to report disease outbreaks and create health alerts**

[![Status](https://img.shields.io/badge/status-production--ready-brightgreen)]()
[![Python](https://img.shields.io/badge/python-3.11+-blue)]()
[![License](https://img.shields.io/badge/license-MIT-blue)]()

---

## 📋 Overview

SymptoMap Doctor Station is a complete, production-ready web application that enables healthcare professionals to:

- ✅ **Manually submit outbreak data** with comprehensive form validation
- ✅ **Create and manage health alerts** for affected regions
- ✅ **Mark precise locations** on interactive maps
- ✅ **View real-time statistics** and submitted data
- ✅ **Access via shareable URL** with secure authentication
- ✅ **Export and import data** via CSV files

---

## 🚀 Quick Start

### Option 1: Local Development (5 minutes)

```bash
# 1. Clone repository
cd symptomap-doctor-station

# 2. Start backend
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py

# 3. Open frontend
# Open frontend/index.html in your browser
# OR
python -m http.server 3000

# 4. Login
# URL: http://localhost:3000
# Password: Doctor@SymptoMap2025
```

### Option 2: Docker Deployment (2 minutes)

```bash
cd deployment
docker-compose up -d
```

Access at: `http://localhost`

### Option 3: Cloud Deployment (10 minutes)

Deploy to Render.com, Railway.app, or Vercel - See [Deployment Guide](docs/DEPLOYMENT_GUIDE.md)

---

## 📁 Project Structure

```
symptomap-doctor-station/
├── backend/                    # FastAPI backend
│   ├── main.py                # Main application
│   ├── requirements.txt       # Python dependencies
│   └── Dockerfile            # Docker configuration
│
├── frontend/                   # React frontend (single HTML)
│   └── index.html            # Complete web application
│
├── deployment/                 # Deployment configurations
│   ├── docker-compose.yml    # Docker Compose setup
│   ├── nginx.conf            # Nginx configuration
│   └── .env.example          # Environment variables template
│
├── scripts/                    # Utility scripts
│   ├── backup_database.py    # Database backup utility
│   └── import_data.py        # CSV import utility
│
├── docs/                       # Documentation
│   ├── DEPLOYMENT_GUIDE.md   # Complete deployment instructions
│   ├── USER_MANUAL.md        # Doctor user guide
│   └── API_DOCUMENTATION.md  # API reference
│
├── data/                       # Data directory (auto-created)
│   └── symptomap.db          # SQLite database
│
└── README.md                  # This file
```

---

## ✨ Features

### 🔐 Authentication & Security
- JWT token-based authentication
- Single password system (configurable)
- 24-hour token expiry
- Failed login attempt tracking (5 attempts, 15-min lockout)
- Session management

### 📝 Outbreak Submission
- Comprehensive form with validation
- 12+ disease types (expandable)
- Patient count tracking (1-10,000)
- Severity levels (Mild/Moderate/Severe)
- Interactive map location picker
- Hospital/clinic information
- Symptom tracking
- Treatment status

### 🗺️ Interactive Map Features
- OpenStreetMap integration
- Click-to-mark locations
- Quick location buttons for major cities
- Draggable markers
- Coordinate display
- Zoom and pan controls
- Responsive design

### 🚨 Alert Management System
- Three alert types (Critical/Warning/Info)
- Priority levels (1-3)
- Affected area radius
- Auto-expiry system
- Action recommendations
- Contact information
- Category classification

### 📊 Dashboard & Analytics
- Real-time statistics
- Total outbreaks count
- Active alerts count
- Today's submissions
- Top diseases tracking
- Submission history
- Delete functionality

### 💾 Data Management
- SQLite database (production-ready)
- Automated backups (every 6 hours)
- CSV import/export
- Data validation
- Soft delete (data preservation)

---

## 🛠️ Technology Stack

### Backend
- **Framework**: FastAPI (Python 3.11+)
- **Database**: SQLite (upgradeable to PostgreSQL)
- **Authentication**: JWT (PyJWT)
- **Validation**: Pydantic
- **Server**: Uvicorn

### Frontend
- **Framework**: React 18 (standalone)
- **Maps**: Leaflet + OpenStreetMap
- **Styling**: Custom CSS
- **Transpiler**: Babel (standalone)

### Deployment
- **Containerization**: Docker + Docker Compose
- **Web Server**: Nginx
- **Cloud Platforms**: Render, Railway, Vercel, Netlify
- **SSL**: Automatic (via cloud providers)

---

## 📖 Documentation

| Document | Description |
|----------|-------------|
| [Deployment Guide](docs/DEPLOYMENT_GUIDE.md) | Complete deployment instructions for all platforms |
| [User Manual](docs/USER_MANUAL.md) | Step-by-step guide for doctors |
| [BRD](docs/BRD.md) | Business Requirements Document |

---

## 🔧 Configuration

### Backend Environment Variables

```env
SECRET_KEY=your-secret-key-here
DOCTOR_PASSWORD=Doctor@SymptoMap2025
DATABASE_PATH=/path/to/symptomap.db
JWT_EXPIRATION_HOURS=24
PORT=8000
```

### Frontend Configuration

Update `API_BASE_URL` in `frontend/index.html`:

```javascript
// Development
const API_BASE_URL = 'http://localhost:8000';

// Production
const API_BASE_URL = 'https://your-backend-domain.com';
```

---

## 🗄️ Database Schema

### Outbreaks Table
```sql
doctor_outbreaks (
    id, disease_type, patient_count, severity,
    latitude, longitude, location_name, city, state, country,
    description, symptoms, treatment_status, date_reported,
    submitted_by, submitted_at, updated_at, status, verification_status
)
```

### Alerts Table
```sql
doctor_alerts (
    id, alert_type, title, message, affected_area,
    latitude, longitude, radius_km, priority, category,
    contact_info, action_required, expiry_date,
    created_at, created_by, status, views_count
)
```

---

## 📡 API Endpoints

### Authentication
```
POST   /api/v1/doctor/login          # Login
POST   /api/v1/doctor/verify-token   # Verify token
```

### Outbreak Management
```
POST   /api/v1/doctor/outbreak       # Submit outbreak
GET    /api/v1/doctor/outbreaks      # List outbreaks
GET    /api/v1/doctor/outbreak/{id}  # Get specific outbreak
DELETE /api/v1/doctor/outbreak/{id}  # Delete outbreak
```

### Alert Management
```
POST   /api/v1/doctor/alert          # Create alert
GET    /api/v1/doctor/alerts         # List alerts
DELETE /api/v1/doctor/alert/{id}     # Delete alert
```

### Public Endpoints (No auth)
```
GET    /api/v1/outbreaks/public      # Public outbreak data
GET    /api/v1/alerts/public         # Public alerts
GET    /api/v1/stats/public          # Statistics
GET    /health                       # Health check
```

---

## 🔒 Security Features

1. **Authentication**: JWT token-based with configurable expiry
2. **Rate Limiting**: 5 failed login attempts = 15-minute lockout
3. **Input Validation**: Pydantic models validate all inputs
4. **SQL Injection Prevention**: Parameterized queries
5. **CORS Protection**: Configurable allowed origins
6. **HTTPS Support**: SSL via reverse proxy
7. **Session Management**: Auto-logout after inactivity
8. **Password Security**: Configurable, non-hardcoded

---

## 🚀 Deployment Options

### ☁️ Cloud Platforms (Recommended)

| Platform | Pros | Free Tier | SSL | Setup Time |
|----------|------|-----------|-----|------------|
| **Render.com** | Easy, auto-SSL | ✅ Yes | ✅ Auto | 10 min |
| **Railway.app** | Simple, fast | ✅ Limited | ✅ Auto | 5 min |
| **Vercel** | Fast CDN | ✅ Yes | ✅ Auto | 5 min |
| **Netlify** | Great for static | ✅ Yes | ✅ Auto | 5 min |

### 🐳 Docker Deployment

```bash
docker-compose up -d
```

### 🖥️ VPS/Self-Hosted

1. Install Python 3.11+
2. Clone repository
3. Configure environment
4. Set up Nginx/Apache
5. Configure SSL (Let's Encrypt)
6. Run with systemd/supervisor

---

## 🧪 Testing

### Backend Tests
```bash
cd backend
pytest tests/
```

### API Testing
```bash
# Health check
curl http://localhost:8000/health

# Login
curl -X POST http://localhost:8000/api/v1/doctor/login \
  -H "Content-Type: application/json" \
  -d '{"password":"Doctor@SymptoMap2025"}'
```

---

## 🔄 Data Management

### Backup Database
```bash
python scripts/backup_database.py backup
```

### List Backups
```bash
python scripts/backup_database.py list
```

### Restore Database
```bash
python scripts/backup_database.py restore backups/backup_file.db
```

### Import Data from CSV
```bash
# Generate sample CSVs
python scripts/import_data.py sample-outbreak
python scripts/import_data.py sample-alert

# Import data
python scripts/import_data.py outbreaks data.csv
python scripts/import_data.py alerts alerts.csv
```

---

## 📊 Monitoring

### Health Check
```bash
curl http://localhost:8000/health
```

Expected response:
```json
{
  "status": "healthy",
  "database": "connected",
  "timestamp": "2025-01-30T12:00:00"
}
```

### View Logs

**Docker**:
```bash
docker-compose logs -f backend
```

**Local**:
Check terminal where backend is running

### Database Statistics
```bash
sqlite3 data/symptomap.db "SELECT COUNT(*) FROM doctor_outbreaks;"
sqlite3 data/symptomap.db "SELECT COUNT(*) FROM doctor_alerts;"
```

---

## 🐛 Troubleshooting

### Common Issues

**Backend won't start**
```bash
# Port already in use
lsof -ti:8000 | xargs kill -9
```

**Frontend can't connect**
- Check backend is running: `curl http://localhost:8000/health`
- Verify API_BASE_URL in frontend code
- Check CORS settings

**Login fails**
- Verify password exactly: `Doctor@SymptoMap2025`
- Check browser console for errors
- Test backend directly with curl

**Map not loading**
- Check internet connection (needs OpenStreetMap)
- Check browser console
- Try different browser

See [Deployment Guide](docs/DEPLOYMENT_GUIDE.md) for detailed troubleshooting.

---

## 🎯 Production Checklist

Before going live:

- [ ] Change default password
- [ ] Configure HTTPS/SSL
- [ ] Set up automated backups
- [ ] Configure CORS for production domain
- [ ] Set up monitoring/logging
- [ ] Test all features thoroughly
- [ ] Create user documentation
- [ ] Train staff on system usage
- [ ] Set up database backups
- [ ] Configure firewall rules
- [ ] Test disaster recovery
- [ ] Set up health monitoring

---

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

---

## 📝 License

This project is licensed under the MIT License - see LICENSE file for details.

---

## 👥 Authors

- **Development Team** - Initial work

---

## 🙏 Acknowledgments

- OpenStreetMap for map tiles
- Leaflet for mapping library
- FastAPI community
- React community
- All healthcare workers using this system

---

## 📧 Support

- **Documentation**: Check `/docs` folder
- **Issues**: Open GitHub issue
- **Email**: [contact email]

---

## 🔄 Changelog

### Version 1.0.0 (2025-01-30)
- ✨ Initial release
- ✨ Doctor authentication system
- ✨ Outbreak submission with validation
- ✨ Interactive map picker
- ✨ Alert management system
- ✨ Real-time dashboard
- ✨ Database backup utilities
- ✨ CSV import/export
- ✨ Complete documentation
- ✨ Docker support
- ✨ Production-ready deployment

---

## 🎯 Roadmap

### Version 1.1 (Planned)
- [ ] Multi-doctor accounts with unique credentials
- [ ] Email notifications for new alerts
- [ ] SMS integration
- [ ] Mobile app (React Native)
- [ ] Advanced analytics dashboard
- [ ] Data visualization charts
- [ ] Export to PDF reports
- [ ] Multi-language support
- [ ] Role-based access control
- [ ] Audit logging

### Version 2.0 (Future)
- [ ] Machine learning outbreak prediction
- [ ] Integration with national health databases
- [ ] Real-time WebSocket updates
- [ ] Geofenced push notifications
- [ ] Advanced search and filtering
- [ ] Data anonymization tools
- [ ] API for third-party integrations

---

## 📚 Additional Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [React Documentation](https://react.dev/)
- [Leaflet Documentation](https://leafletjs.com/)
- [Docker Documentation](https://docs.docker.com/)
- [Render Deployment Guide](https://render.com/docs)

---

<div align="center">

**Built with ❤️ for healthcare professionals**

[Report Bug](../../issues) · [Request Feature](../../issues) · [Documentation](docs/)

</div>
