# SymptoMap Doctor Station - User Manual

## 🏥 Welcome to SymptoMap Doctor Station

This manual will guide you through using the Doctor Station to report outbreak data and create health alerts.

---

## 📋 Table of Contents

1. [Getting Started](#getting-started)
2. [Logging In](#logging-in)
3. [Submitting Outbreak Data](#submitting-outbreak-data)
4. [Creating Health Alerts](#creating-health-alerts)
5. [Viewing Your Submissions](#viewing-your-submissions)
6. [Best Practices](#best-practices)
7. [FAQ](#frequently-asked-questions)

---

## Getting Started

### What is SymptoMap Doctor Station?

The Doctor Station is a secure web portal that allows healthcare professionals to:
- Report disease outbreaks in real-time
- Create health alerts for affected areas
- Track and manage submitted data
- Contribute to public health monitoring

### System Requirements

- **Internet Connection**: Required
- **Web Browser**: 
  - Chrome 90+ (recommended)
  - Firefox 88+
  - Safari 14+
  - Edge 90+
- **Screen Resolution**: 1024x768 or higher

### Access Information

**Portal URL**: [Your deployment URL here]  
**Password**: `Doctor@SymptoMap2025`

> **Note**: This password is shared among all doctors. Keep it confidential.

---

## Logging In

### Step-by-Step Login Process

1. **Navigate to the Doctor Station**
   - Open your web browser
   - Enter the portal URL
   - You'll see the login screen

2. **View the Password**
   - The system password is displayed on the login screen
   - It's shown in a blue box for easy reference

3. **Enter Password**
   - Type or copy the password: `Doctor@SymptoMap2025`
   - Password is case-sensitive

4. **Click Login**
   - Press "Login to Doctor Station" button
   - You'll be redirected to the dashboard

### Login Security

- **Session Duration**: 24 hours
- **Auto-logout**: After 2 hours of inactivity
- **Failed Attempts**: After 5 failed attempts, wait 15 minutes

### Troubleshooting Login

**Problem**: "Invalid password" error
- **Solution**: Check caps lock is off, copy password exactly as shown

**Problem**: "Too many attempts" error
- **Solution**: Wait 15 minutes before trying again

**Problem**: Page won't load
- **Solution**: Check internet connection, try refreshing page

---

## Submitting Outbreak Data

### When to Submit

Submit outbreak data when you encounter:
- Multiple cases of the same disease
- Unusual disease patterns
- Confirmed disease outbreaks
- Suspected disease clusters

### Required Information

You must provide:
- ✅ Disease type
- ✅ Number of patients
- ✅ Severity level (Mild/Moderate/Severe)
- ✅ Geographic location (map)
- ✅ Date of report

### Optional Information (Recommended)

- Hospital/Clinic name
- City and State
- Detailed description
- Observed symptoms
- Treatment status

---

### Step-by-Step Submission

#### Step 1: Access Submission Form

1. After logging in, you'll see three tabs
2. Click on "📝 Submit Outbreak" tab
3. The outbreak submission form will appear

#### Step 2: Select Disease Type

1. Click the "Disease Type" dropdown
2. Choose from the list:
   - Dengue
   - Malaria
   - COVID-19
   - Influenza
   - Typhoid
   - Chikungunya
   - Tuberculosis
   - Hepatitis A/B/C
   - Cholera
   - Measles
   - Other

3. If "Other", describe in the Description field

#### Step 3: Enter Patient Count

1. Click in the "Patient Count" field
2. Enter the number of affected patients
3. Range: 1 to 10,000
4. The system will warn if count exceeds 100

#### Step 4: Select Date

1. Click the calendar icon in "Date Reported"
2. Select the date outbreak was identified
3. Cannot select future dates
4. Default is today's date

#### Step 5: Choose Severity Level

Select one:
- **🟢 Mild**: Minor symptoms, low hospitalization
- **🟠 Moderate**: Significant symptoms, some hospitalization
- **🔴 Severe**: Serious symptoms, high hospitalization/mortality

#### Step 6: Mark Location on Map

This is the most important step!

**Option A: Use Quick Location Buttons**
1. Click any major city button (e.g., "📍 Mumbai")
2. Map will center on that city
3. Fine-tune by clicking exact location

**Option B: Click Directly on Map**
1. Scroll/zoom to your location
2. Click exact point where outbreak occurred
3. A marker will appear
4. Click again to move marker

**Option C: Manual Coordinates**
1. If you know exact coordinates
2. Type them in the coordinate fields
3. Marker will update automatically

**Tips**:
- Zoom in for accuracy (use mouse wheel or +/- buttons)
- Place marker at hospital/clinic location
- Check coordinates display below map

#### Step 7: Add Location Details

1. **Hospital/Clinic Name**: Enter facility name
   - Example: "AIIMS Delhi", "KEM Hospital"

2. **City**: Enter city name
   - Example: "Mumbai", "Delhi", "Bangalore"

3. **State**: Select from dropdown
   - Choose your state from the list

4. **Country**: Default is "India"
   - Change if needed for border areas

#### Step 8: Add Description (Optional but Recommended)

Provide context about the outbreak:
- When did it start?
- How many days has it been occurring?
- Any specific factors (monsoon, event, etc.)?
- Any patterns observed?

**Example**:
```
"Seasonal dengue outbreak during monsoon period. 
Cases started appearing 10 days ago. Most patients 
from residential areas near stagnant water bodies."
```

Maximum 500 characters.

#### Step 9: Add Symptoms (Optional)

List common symptoms observed:
- Example: "Fever, Headache, Joint pain, Rash"
- Separate with commas
- Help others identify similar cases

#### Step 10: Add Treatment Status (Optional)

Indicate current status:
- "Under treatment"
- "Recovering"
- "Hospitalized"
- "Home care"
- "Critical care required"

#### Step 11: Review and Submit

1. **Review all information**
   - Check disease type is correct
   - Verify patient count
   - Confirm location marker is accurate
   - Review severity level

2. **Click "📤 Submit Outbreak Data"**

3. **Wait for Confirmation**
   - Green success message will appear
   - If error, check required fields

4. **Form will clear** for next submission

### After Submission

Your data is:
- ✅ Saved to secure database
- ✅ Immediately available on public dashboard
- ✅ Visible in "View Submissions" tab
- ✅ Backed up automatically every 6 hours

---

## Creating Health Alerts

### When to Create Alerts

Create alerts for:
- **Critical Situations**: Immediate health threats
- **Public Warnings**: Preventive measures needed
- **Information**: General health updates

### Alert Types

**🔴 Critical**
- Serious health emergency
- Immediate action required
- High priority display
- Example: "Major outbreak confirmed"

**🟠 Warning**
- Caution advised
- Preventive actions recommended
- Medium priority
- Example: "Increasing cases observed"

**🔵 Info**
- General information
- Awareness purposes
- Low priority
- Example: "Vaccination drive scheduled"

---

### Step-by-Step Alert Creation

#### Step 1: Access Alert Form

1. Click "🚨 Create Alert" tab
2. Alert creation form appears

#### Step 2: Select Alert Type

Choose from dropdown:
- 🔴 Critical (highest urgency)
- 🟠 Warning (moderate urgency)
- 🔵 Info (general information)

#### Step 3: Set Priority

Choose 1-3:
- **1**: High priority (shows first)
- **2**: Medium priority
- **3**: Low priority

#### Step 4: Select Category

Choose what the alert is about:
- **Outbreak**: Disease outbreak
- **Weather**: Weather-related health risk
- **Infrastructure**: Hospital/facility issue
- **Other**: Other health matters

#### Step 5: Write Alert Title

Create a clear, concise title (max 100 characters):

**Good Examples**:
- "Dengue Alert - Mumbai Region"
- "COVID-19 Cluster - Bangalore East"
- "Malaria Warning - Monsoon Season"

**Avoid**:
- Vague titles: "Health Alert"
- Too long: "There is a dengue outbreak happening..."

#### Step 6: Write Alert Message

Provide detailed information (max 500 characters):

**Should Include**:
- What is happening
- Where it's happening
- How serious it is
- Time frame

**Example**:
```
"Significant increase in dengue cases reported across 
Mumbai region in past 2 weeks. Over 100 confirmed cases. 
All residents advised to take preventive measures. 
High-risk areas: South Mumbai, Bandra, Andheri."
```

#### Step 7: Specify Affected Area

Enter location name:
- City name: "Mumbai"
- Region: "Mumbai, Maharashtra"
- District: "Pune District"
- Be specific for clarity

#### Step 8: Set Radius

Enter affected area radius in kilometers:
- **Small outbreak**: 5-10 km
- **City-wide**: 20-50 km
- **Regional**: 100+ km

People within this radius will see the alert on map.

#### Step 9: Mark Location on Map

Same process as outbreak submission:
1. Use quick location buttons OR
2. Click on map OR
3. Enter coordinates manually

Place marker at center of affected area.

#### Step 10: Add Action Required (Optional but Recommended)

Tell people what to do:

**Example**:
```
"Avoid stagnant water. Use mosquito repellent. 
Cover water containers. Seek immediate medical 
attention if fever develops. Call helpline: 1800-XXX-XXXX"
```

This helps people protect themselves.

#### Step 11: Add Contact Information (Optional)

Provide helpline or emergency contact:
- "Helpline: 1800-XXX-XXXX"
- "Emergency: 108"
- "Hospital: +91-XXX-XXX-XXXX"

#### Step 12: Set Expiry Duration

Choose how long alert stays active:
- **24 hours**: Short-term alerts
- **168 hours (7 days)**: Standard (default)
- **720 hours (30 days)**: Long-term warnings

Alert automatically deactivates after expiry.

#### Step 13: Review and Create

1. **Review all information**
   - Check alert type matches urgency
   - Verify message is clear
   - Confirm location is correct

2. **Click "🚨 Create Alert"**

3. **Confirmation**
   - Green success message appears
   - Alert is now live
   - Visible on public dashboard immediately

---

## Viewing Your Submissions

### Access Submissions

1. Click "📊 View Submissions" tab
2. You'll see three sections:
   - Statistics cards at top
   - Recent outbreaks list
   - Active alerts list

### Statistics Dashboard

Shows real-time metrics:
- **Total Outbreaks**: All active outbreak records
- **Active Alerts**: Currently active alerts
- **Today's Submissions**: Data submitted today

### Outbreak List

Each outbreak card shows:
- Disease type and location
- Patient count
- Severity level (colored badge)
- Geographic coordinates
- Date reported
- Description (if provided)
- Delete button

### Alert List

Each alert card shows:
- Title
- Alert type (colored badge)
- Full message
- Affected area
- Priority and radius
- Creation date
- Delete button

### Deleting Records

**To delete an outbreak or alert:**

1. Find the record in the list
2. Click red "Delete" button
3. Confirm deletion
4. Record is marked inactive (soft delete)

**Note**: Deletion doesn't remove from database, just hides from public view.

### Refreshing Data

- Data auto-refreshes when you switch tabs
- Click "View Submissions" tab again to manually refresh
- Or refresh browser page

---

## Best Practices

### Data Quality

**DO**:
✅ Provide accurate patient counts
✅ Mark exact location on map
✅ Include detailed descriptions
✅ Use appropriate severity levels
✅ Submit data promptly
✅ Double-check before submitting

**DON'T**:
❌ Guess or estimate wildly
❌ Submit duplicate records
❌ Use vague locations
❌ Exaggerate severity
❌ Include patient names or personal info
❌ Submit unverified data

### Location Accuracy

- **Zoom in** to street level when marking
- Place marker at **actual outbreak site**
- Use **hospital/clinic location** if possible
- Verify **city and state** match location
- Check **coordinates** look correct

### Description Guidelines

**Good Description**:
```
"Confirmed dengue outbreak at XYZ Hospital. 
Started 5 days ago during monsoon. 25 patients 
admitted. Most from nearby residential area. 
Blood tests confirmed. Active treatment ongoing."
```

**Poor Description**:
```
"Some dengue cases"
```

### Alert Guidelines

**Effective Alerts**:
- Clear and specific
- Include actionable advice
- Mention time frame
- Provide contact info
- Use appropriate urgency level

**Ineffective Alerts**:
- Vague or confusing
- No action items
- Overly alarming without context
- Missing key details

### Security Practices

- **Never share** login password publicly
- **Logout** when finished
- **Don't leave** computer unattended while logged in
- **Use secure** internet connection
- **Report** any suspicious activity

### Data Privacy

- **Don't include** patient names
- **Don't share** personal health information
- **Don't mention** identifiable details
- **Focus on** aggregate data and patterns
- **Follow** HIPAA/privacy guidelines

---

## Frequently Asked Questions

### General Questions

**Q: Who can access the Doctor Station?**  
A: Any authorized healthcare professional with the password.

**Q: Is the data public?**  
A: Yes, submitted outbreaks and alerts appear on public dashboard, but without personal identifiers.

**Q: How long does data stay in system?**  
A: Indefinitely, but can be marked inactive by deleting.

**Q: Can I edit submitted data?**  
A: Currently no edit function. Delete and re-submit if needed.

### Technical Questions

**Q: What if map doesn't load?**  
A: Check internet connection. Try refreshing page. Ensure browser is updated.

**Q: Can I use on mobile phone?**  
A: Yes, responsive design works on mobile, but desktop recommended for map interaction.

**Q: What browsers are supported?**  
A: Chrome, Firefox, Safari, Edge (latest versions).

**Q: Will my session expire?**  
A: Yes, after 24 hours or 2 hours of inactivity.

### Data Questions

**Q: What if I don't know exact patient count?**  
A: Provide best estimate. Indicate in description it's approximate.

**Q: Can I submit data from multiple locations?**  
A: Yes, submit separate record for each location.

**Q: What if outbreak spans multiple cities?**  
A: Submit for primary location, mention other areas in description.

**Q: Should I submit suspected cases?**  
A: Yes, but indicate "suspected" in description and choose lower severity.

### Alert Questions

**Q: How long should I make alert active?**  
A: Standard 7 days. Adjust based on situation urgency.

**Q: Can I have multiple active alerts?**  
A: Yes, no limit on active alerts.

**Q: What happens when alert expires?**  
A: Automatically removed from public view, but remains in database.

**Q: Should I create alert for every outbreak?**  
A: Only if public action/awareness is needed.

### Problem Resolution

**Q: Submission failed, what to do?**  
A: Check all required fields filled. Verify internet connection. Try again.

**Q: Forgot password?**  
A: Password is displayed on login screen. Cannot be reset by users.

**Q: Data not showing on dashboard?**  
A: Wait 30 seconds and refresh. Check "View Submissions" tab.

**Q: Map marker not moving?**  
A: Try clearing browser cache. Use different browser.

---

## Getting Help

### Need Assistance?

1. **Review this manual** - Most questions answered here
2. **Check FAQ section** - Common issues resolved
3. **Contact system administrator** - For technical support
4. **Report bugs** - Help improve the system

### Providing Feedback

Your feedback helps improve the system:
- Suggest new features
- Report bugs or issues
- Share usability concerns
- Request additional training

---

## Quick Reference Card

### Login
```
URL: [Your deployment URL]
Password: Doctor@SymptoMap2025
```

### Submit Outbreak
1. Click "Submit Outbreak" tab
2. Fill required fields (disease, count, date, severity)
3. Click map to mark location
4. Add details
5. Submit

### Create Alert
1. Click "Create Alert" tab
2. Choose type and priority
3. Write title and message
4. Mark location
5. Set expiry
6. Create

### View Data
1. Click "View Submissions" tab
2. See statistics
3. Review outbreaks
4. Check alerts
5. Delete if needed

---

## Contact Information

**System Administrator**: [Contact details]  
**Technical Support**: [Support email/phone]  
**Emergency Hotline**: [Emergency contact]

---

**Version 1.0** - Last Updated: January 30, 2025

Thank you for using SymptoMap Doctor Station to help protect public health!
