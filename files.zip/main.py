"""
SymptoMap Doctor Station - Backend API
Complete FastAPI implementation with authentication, outbreak management, and alerts
"""

from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime, timedelta
import jwt
import sqlite3
import os
from contextlib import contextmanager
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
SECRET_KEY = os.getenv("SECRET_KEY", "symptomap-doctor-secret-key-2025")
ALGORITHM = "HS256"
DOCTOR_PASSWORD = os.getenv("DOCTOR_PASSWORD", "Doctor@SymptoMap2025")
DATABASE_PATH = os.getenv("DATABASE_PATH", "symptomap.db")
TOKEN_EXPIRE_HOURS = 24

# Initialize FastAPI app
app = FastAPI(
    title="SymptoMap Doctor Station API",
    description="Secure API for healthcare professionals to report outbreaks and create alerts",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure based on deployment
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# ============================================================================
# DATABASE SETUP
# ============================================================================

def init_database():
    """Initialize SQLite database with required tables"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Outbreaks table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS doctor_outbreaks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            disease_type VARCHAR(100) NOT NULL,
            patient_count INTEGER NOT NULL CHECK(patient_count > 0),
            severity VARCHAR(20) NOT NULL CHECK(severity IN ('mild', 'moderate', 'severe')),
            latitude DECIMAL(10, 8) NOT NULL,
            longitude DECIMAL(11, 8) NOT NULL,
            location_name VARCHAR(255),
            city VARCHAR(100),
            state VARCHAR(100),
            country VARCHAR(100) DEFAULT 'India',
            description TEXT,
            symptoms TEXT,
            treatment_status VARCHAR(50),
            date_reported DATE NOT NULL,
            submitted_by VARCHAR(100) DEFAULT 'doctor',
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(20) DEFAULT 'active',
            verification_status VARCHAR(20) DEFAULT 'verified'
        )
    """)
    
    # Alerts table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS doctor_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_type VARCHAR(20) NOT NULL CHECK(alert_type IN ('critical', 'warning', 'info')),
            title VARCHAR(100) NOT NULL,
            message TEXT NOT NULL,
            affected_area VARCHAR(255),
            latitude DECIMAL(10, 8),
            longitude DECIMAL(11, 8),
            radius_km DECIMAL(6, 2),
            priority INTEGER CHECK(priority IN (1, 2, 3)),
            category VARCHAR(50),
            contact_info VARCHAR(255),
            action_required TEXT,
            expiry_date TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by VARCHAR(100) DEFAULT 'doctor',
            status VARCHAR(20) DEFAULT 'active',
            views_count INTEGER DEFAULT 0
        )
    """)
    
    # Login attempts tracking
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS login_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address VARCHAR(45),
            success BOOLEAN,
            attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    conn.close()
    logger.info("✅ Database initialized successfully")

@contextmanager
def get_db_connection():
    """Context manager for database connections"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    init_database()

# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class LoginRequest(BaseModel):
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = TOKEN_EXPIRE_HOURS * 3600

class OutbreakSubmission(BaseModel):
    disease_type: str = Field(..., min_length=2, max_length=100)
    patient_count: int = Field(..., gt=0, le=10000)
    severity: str = Field(..., pattern="^(mild|moderate|severe)$")
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    location_name: Optional[str] = Field(None, max_length=255)
    city: Optional[str] = Field(None, max_length=100)
    state: Optional[str] = Field(None, max_length=100)
    country: str = Field(default="India", max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    symptoms: Optional[str] = Field(None, max_length=500)
    treatment_status: Optional[str] = Field(None, max_length=50)
    date_reported: str  # ISO date string
    
    @validator('date_reported')
    def validate_date(cls, v):
        try:
            date = datetime.fromisoformat(v.replace('Z', '+00:00'))
            if date > datetime.now():
                raise ValueError('Date cannot be in the future')
            return v
        except:
            raise ValueError('Invalid date format')

class AlertSubmission(BaseModel):
    alert_type: str = Field(..., pattern="^(critical|warning|info)$")
    title: str = Field(..., min_length=5, max_length=100)
    message: str = Field(..., min_length=10, max_length=500)
    affected_area: str = Field(..., max_length=255)
    latitude: Optional[float] = Field(None, ge=-90, le=90)
    longitude: Optional[float] = Field(None, ge=-180, le=180)
    radius_km: Optional[float] = Field(default=10, ge=0, le=1000)
    priority: int = Field(default=2, ge=1, le=3)
    category: str = Field(default="outbreak", max_length=50)
    contact_info: Optional[str] = Field(None, max_length=255)
    action_required: Optional[str] = Field(None, max_length=500)
    expiry_hours: int = Field(default=168, ge=1, le=720)  # Default 7 days

class OutbreakResponse(BaseModel):
    id: int
    disease_type: str
    patient_count: int
    severity: str
    latitude: float
    longitude: float
    location_name: Optional[str]
    city: Optional[str]
    state: Optional[str]
    country: str
    description: Optional[str]
    date_reported: str
    submitted_at: str
    status: str

class AlertResponse(BaseModel):
    id: int
    alert_type: str
    title: str
    message: str
    affected_area: str
    latitude: Optional[float]
    longitude: Optional[float]
    radius_km: Optional[float]
    priority: int
    category: str
    expiry_date: Optional[str]
    created_at: str
    status: str

# ============================================================================
# AUTHENTICATION
# ============================================================================

def create_access_token(data: dict) -> str:
    """Create JWT access token"""
    expire = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    to_encode = data.copy()
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    """Verify JWT token and return payload"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

async def check_login_attempts(ip_address: str) -> bool:
    """Check if IP has too many failed login attempts"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) as count FROM login_attempts
            WHERE ip_address = ? 
            AND success = 0 
            AND attempted_at > datetime('now', '-15 minutes')
        """, (ip_address,))
        result = cursor.fetchone()
        return result['count'] < 5

def log_login_attempt(ip_address: str, success: bool):
    """Log login attempt to database"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO login_attempts (ip_address, success)
            VALUES (?, ?)
        """, (ip_address, success))
        conn.commit()

# ============================================================================
# API ENDPOINTS - AUTHENTICATION
# ============================================================================

@app.post("/api/v1/doctor/login", response_model=TokenResponse)
async def doctor_login(request: Request, login_data: LoginRequest):
    """Authenticate doctor and return JWT token"""
    
    # Get client IP
    client_ip = request.client.host
    
    # Check login attempts
    if not await check_login_attempts(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many failed login attempts. Please try again in 15 minutes."
        )
    
    # Verify password
    if login_data.password != DOCTOR_PASSWORD:
        log_login_attempt(client_ip, False)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid password"
        )
    
    # Log successful login
    log_login_attempt(client_ip, True)
    
    # Create token
    access_token = create_access_token({"sub": "doctor", "role": "doctor"})
    
    logger.info(f"✅ Doctor logged in from IP: {client_ip}")
    
    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        expires_in=TOKEN_EXPIRE_HOURS * 3600
    )

@app.post("/api/v1/doctor/verify-token")
async def verify_token_endpoint(payload: dict = Depends(verify_token)):
    """Verify if token is valid"""
    return {"valid": True, "role": payload.get("role")}

# ============================================================================
# API ENDPOINTS - OUTBREAK MANAGEMENT
# ============================================================================

@app.post("/api/v1/doctor/outbreak", status_code=status.HTTP_201_CREATED)
async def submit_outbreak(
    outbreak: OutbreakSubmission,
    payload: dict = Depends(verify_token)
):
    """Submit new outbreak data"""
    
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO doctor_outbreaks 
                (disease_type, patient_count, severity, latitude, longitude,
                 location_name, city, state, country, description, symptoms,
                 treatment_status, date_reported, submitted_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                outbreak.disease_type,
                outbreak.patient_count,
                outbreak.severity,
                outbreak.latitude,
                outbreak.longitude,
                outbreak.location_name,
                outbreak.city,
                outbreak.state,
                outbreak.country,
                outbreak.description,
                outbreak.symptoms,
                outbreak.treatment_status,
                outbreak.date_reported,
                payload.get("sub", "doctor")
            ))
            conn.commit()
            outbreak_id = cursor.lastrowid
            
        logger.info(f"✅ Outbreak submitted: ID {outbreak_id}, Disease: {outbreak.disease_type}")
        
        return {
            "success": True,
            "id": outbreak_id,
            "message": "Outbreak data submitted successfully"
        }
    
    except Exception as e:
        logger.error(f"❌ Error submitting outbreak: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to submit outbreak: {str(e)}"
        )

@app.get("/api/v1/doctor/outbreaks", response_model=List[OutbreakResponse])
async def get_outbreaks(
    limit: int = 50,
    offset: int = 0,
    payload: dict = Depends(verify_token)
):
    """Get all outbreak records"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM doctor_outbreaks 
            WHERE status = 'active'
            ORDER BY submitted_at DESC
            LIMIT ? OFFSET ?
        """, (limit, offset))
        
        rows = cursor.fetchall()
        
        outbreaks = []
        for row in rows:
            outbreaks.append({
                "id": row['id'],
                "disease_type": row['disease_type'],
                "patient_count": row['patient_count'],
                "severity": row['severity'],
                "latitude": row['latitude'],
                "longitude": row['longitude'],
                "location_name": row['location_name'],
                "city": row['city'],
                "state": row['state'],
                "country": row['country'],
                "description": row['description'],
                "date_reported": row['date_reported'],
                "submitted_at": row['submitted_at'],
                "status": row['status']
            })
        
        return outbreaks

@app.get("/api/v1/doctor/outbreak/{outbreak_id}")
async def get_outbreak(
    outbreak_id: int,
    payload: dict = Depends(verify_token)
):
    """Get specific outbreak by ID"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM doctor_outbreaks WHERE id = ?",
            (outbreak_id,)
        )
        row = cursor.fetchone()
        
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Outbreak not found"
            )
        
        return dict(row)

@app.delete("/api/v1/doctor/outbreak/{outbreak_id}")
async def delete_outbreak(
    outbreak_id: int,
    payload: dict = Depends(verify_token)
):
    """Soft delete outbreak (set status to inactive)"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE doctor_outbreaks 
            SET status = 'inactive', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (outbreak_id,))
        conn.commit()
        
        if cursor.rowcount == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Outbreak not found"
            )
        
        return {"success": True, "message": "Outbreak deleted successfully"}

# ============================================================================
# API ENDPOINTS - ALERT MANAGEMENT
# ============================================================================

@app.post("/api/v1/doctor/alert", status_code=status.HTTP_201_CREATED)
async def create_alert(
    alert: AlertSubmission,
    payload: dict = Depends(verify_token)
):
    """Create new health alert"""
    
    try:
        expiry_date = datetime.now() + timedelta(hours=alert.expiry_hours)
        
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO doctor_alerts 
                (alert_type, title, message, affected_area, latitude, longitude,
                 radius_km, priority, category, contact_info, action_required,
                 expiry_date, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                alert.alert_type,
                alert.title,
                alert.message,
                alert.affected_area,
                alert.latitude,
                alert.longitude,
                alert.radius_km,
                alert.priority,
                alert.category,
                alert.contact_info,
                alert.action_required,
                expiry_date.isoformat(),
                payload.get("sub", "doctor")
            ))
            conn.commit()
            alert_id = cursor.lastrowid
        
        logger.info(f"✅ Alert created: ID {alert_id}, Type: {alert.alert_type}")
        
        return {
            "success": True,
            "id": alert_id,
            "message": "Alert created successfully"
        }
    
    except Exception as e:
        logger.error(f"❌ Error creating alert: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create alert: {str(e)}"
        )

@app.get("/api/v1/doctor/alerts", response_model=List[AlertResponse])
async def get_alerts(
    active_only: bool = True,
    limit: int = 50,
    payload: dict = Depends(verify_token)
):
    """Get all alerts"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        if active_only:
            cursor.execute("""
                SELECT * FROM doctor_alerts 
                WHERE status = 'active' 
                AND (expiry_date IS NULL OR expiry_date > datetime('now'))
                ORDER BY priority ASC, created_at DESC
                LIMIT ?
            """, (limit,))
        else:
            cursor.execute("""
                SELECT * FROM doctor_alerts 
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))
        
        rows = cursor.fetchall()
        
        alerts = []
        for row in rows:
            alerts.append({
                "id": row['id'],
                "alert_type": row['alert_type'],
                "title": row['title'],
                "message": row['message'],
                "affected_area": row['affected_area'],
                "latitude": row['latitude'],
                "longitude": row['longitude'],
                "radius_km": row['radius_km'],
                "priority": row['priority'],
                "category": row['category'],
                "expiry_date": row['expiry_date'],
                "created_at": row['created_at'],
                "status": row['status']
            })
        
        return alerts

@app.delete("/api/v1/doctor/alert/{alert_id}")
async def delete_alert(
    alert_id: int,
    payload: dict = Depends(verify_token)
):
    """Delete alert"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE doctor_alerts 
            SET status = 'inactive'
            WHERE id = ?
        """, (alert_id,))
        conn.commit()
        
        if cursor.rowcount == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Alert not found"
            )
        
        return {"success": True, "message": "Alert deleted successfully"}

# ============================================================================
# PUBLIC API ENDPOINTS (No authentication required)
# ============================================================================

@app.get("/api/v1/outbreaks/public")
async def get_public_outbreaks(limit: int = 100):
    """Get outbreak data for public dashboard"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, disease_type, patient_count, severity, latitude, longitude,
                   city, state, date_reported, submitted_at
            FROM doctor_outbreaks 
            WHERE status = 'active'
            AND verification_status = 'verified'
            ORDER BY submitted_at DESC
            LIMIT ?
        """, (limit,))
        
        rows = cursor.fetchall()
        return [dict(row) for row in rows]

@app.get("/api/v1/alerts/public")
async def get_public_alerts():
    """Get active alerts for public dashboard"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, alert_type, title, message, affected_area, 
                   latitude, longitude, radius_km, priority, category,
                   expiry_date, created_at
            FROM doctor_alerts 
            WHERE status = 'active' 
            AND (expiry_date IS NULL OR expiry_date > datetime('now'))
            ORDER BY priority ASC, created_at DESC
        """)
        
        rows = cursor.fetchall()
        return [dict(row) for row in rows]

@app.get("/api/v1/stats/public")
async def get_public_stats():
    """Get statistics for public dashboard"""
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Total outbreaks
        cursor.execute("SELECT COUNT(*) as count FROM doctor_outbreaks WHERE status = 'active'")
        total_outbreaks = cursor.fetchone()['count']
        
        # Active alerts
        cursor.execute("""
            SELECT COUNT(*) as count FROM doctor_alerts 
            WHERE status = 'active' 
            AND (expiry_date IS NULL OR expiry_date > datetime('now'))
        """)
        active_alerts = cursor.fetchone()['count']
        
        # Today's submissions
        cursor.execute("""
            SELECT COUNT(*) as count FROM doctor_outbreaks 
            WHERE DATE(submitted_at) = DATE('now')
        """)
        today_submissions = cursor.fetchone()['count']
        
        # Top diseases
        cursor.execute("""
            SELECT disease_type, COUNT(*) as count 
            FROM doctor_outbreaks 
            WHERE status = 'active'
            GROUP BY disease_type 
            ORDER BY count DESC 
            LIMIT 5
        """)
        top_diseases = [dict(row) for row in cursor.fetchall()]
        
        return {
            "total_outbreaks": total_outbreaks,
            "active_alerts": active_alerts,
            "today_submissions": today_submissions,
            "top_diseases": top_diseases,
            "last_updated": datetime.now().isoformat()
        }

# ============================================================================
# UTILITY ENDPOINTS
# ============================================================================

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "SymptoMap Doctor Station API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "login": "/api/v1/doctor/login",
            "submit_outbreak": "/api/v1/doctor/outbreak",
            "create_alert": "/api/v1/doctor/alert",
            "public_outbreaks": "/api/v1/outbreaks/public",
            "public_alerts": "/api/v1/alerts/public"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
        
        return {
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "database": "disconnected",
            "error": str(e)
        }

# ============================================================================
# RUN APPLICATION
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    port = int(os.getenv("PORT", 8000))
    
    logger.info("🚀 Starting SymptoMap Doctor Station API")
    logger.info(f"📍 Server running on http://0.0.0.0:{port}")
    logger.info(f"🔑 Doctor Password: {DOCTOR_PASSWORD}")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=port,
        reload=True,
        log_level="info"
    )
