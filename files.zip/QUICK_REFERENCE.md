# SymptoMap Doctor Station - Quick Reference Guide

## 🚀 5-Minute Quick Start

### For Local Development

```bash
# 1. Navigate to project
cd symptomap-doctor-station

# 2. Run the quick start script
./start.sh

# 3. Open frontend/index.html in browser

# 4. Login
Password: Doctor@SymptoMap2025
```

### For Docker

```bash
cd deployment
docker-compose up -d
# Access at http://localhost
```

---

## 🔐 Access Credentials

| Field | Value |
|-------|-------|
| **URL** | Your deployment URL |
| **Password** | `Doctor@SymptoMap2025` |
| **Session** | 24 hours |
| **Timeout** | 2 hours inactivity |

---

## 📝 Quick Actions

### Submit Outbreak
1. Login → "Submit Outbreak" tab
2. Select disease, count, severity, date
3. Click map to mark location
4. Fill details
5. Submit

### Create Alert
1. Login → "Create Alert" tab
2. Choose type (Critical/Warning/Info)
3. Write title & message
4. Mark location
5. Set expiry
6. Create

### View Data
1. Login → "View Submissions" tab
2. See statistics
3. Browse outbreaks & alerts
4. Delete if needed

---

## 🗺️ Major City Coordinates

| City | Coordinates |
|------|-------------|
| Mumbai | 19.0760°N, 72.8777°E |
| Delhi | 28.7041°N, 77.1025°E |
| Bangalore | 12.9716°N, 77.5946°E |
| Kolkata | 22.5726°N, 88.3639°E |
| Chennai | 13.0827°N, 80.2707°E |
| Hyderabad | 17.3850°N, 78.4867°E |
| Pune | 18.5204°N, 73.8567°E |
| Ahmedabad | 23.0225°N, 72.5714°E |
| Jaipur | 26.9124°N, 75.7873°E |
| Surat | 21.1702°N, 72.8311°E |

---

## 🦠 Disease Types

- Dengue
- Malaria
- COVID-19
- Influenza
- Typhoid
- Chikungunya
- Tuberculosis
- Hepatitis A/B/C
- Cholera
- Measles
- Other

---

## ⚡ Severity Levels

| Level | Badge | Use When |
|-------|-------|----------|
| 🟢 Mild | Green | Minor symptoms, low hospitalization |
| 🟠 Moderate | Orange | Significant symptoms, some hospitalization |
| 🔴 Severe | Red | Serious symptoms, high mortality risk |

---

## 🚨 Alert Types

| Type | Color | Priority | Use For |
|------|-------|----------|---------|
| 🔴 Critical | Red | Highest | Immediate health emergency |
| 🟠 Warning | Orange | Medium | Caution advised |
| 🔵 Info | Blue | Low | General information |

---

## 📡 API Endpoints (Quick Reference)

### Authentication
```
POST /api/v1/doctor/login
POST /api/v1/doctor/verify-token
```

### Outbreaks
```
POST   /api/v1/doctor/outbreak
GET    /api/v1/doctor/outbreaks
DELETE /api/v1/doctor/outbreak/{id}
```

### Alerts
```
POST   /api/v1/doctor/alert
GET    /api/v1/doctor/alerts
DELETE /api/v1/doctor/alert/{id}
```

### Public
```
GET /api/v1/outbreaks/public
GET /api/v1/alerts/public
GET /api/v1/stats/public
GET /health
```

---

## 🔧 Command Cheat Sheet

### Backend
```bash
# Start server
python backend/main.py

# Check health
curl http://localhost:8000/health

# Test login
curl -X POST http://localhost:8000/api/v1/doctor/login \
  -H "Content-Type: application/json" \
  -d '{"password":"Doctor@SymptoMap2025"}'
```

### Database
```bash
# Backup
python scripts/backup_database.py backup

# List backups
python scripts/backup_database.py list

# Restore
python scripts/backup_database.py restore <file>

# View data
sqlite3 symptomap.db "SELECT * FROM doctor_outbreaks LIMIT 5;"
```

### Import Data
```bash
# Generate samples
python scripts/import_data.py sample-outbreak
python scripts/import_data.py sample-alert

# Import
python scripts/import_data.py outbreaks data.csv
python scripts/import_data.py alerts alerts.csv
```

### Docker
```bash
# Start
docker-compose up -d

# Stop
docker-compose down

# Logs
docker-compose logs -f backend

# Restart
docker-compose restart
```

---

## 🐛 Common Issues & Fixes

### Backend won't start
```bash
# Kill process on port 8000
lsof -ti:8000 | xargs kill -9
# or
pkill -f "python main.py"
```

### Frontend can't connect
```javascript
// Check API_BASE_URL in frontend/index.html
const API_BASE_URL = 'http://localhost:8000';
```

### Login fails
- Verify password exactly: `Doctor@SymptoMap2025`
- Check browser console for errors
- Try incognito/private mode

### Map not loading
- Check internet connection
- Verify Leaflet library loads
- Check browser console
- Try different browser

### Database locked
```bash
# Close all connections
rm symptomap.db
python backend/main.py  # Recreates database
```

---

## 📊 Health Check

```bash
# Check backend
curl http://localhost:8000/health

# Expected response
{
  "status": "healthy",
  "database": "connected",
  "timestamp": "2025-01-30T12:00:00"
}
```

---

## 🔒 Security Checklist

- [ ] Change default password
- [ ] Enable HTTPS/SSL
- [ ] Configure CORS properly
- [ ] Set up firewall rules
- [ ] Enable rate limiting
- [ ] Configure backups
- [ ] Monitor logs
- [ ] Update dependencies

---

## 📞 Support Contacts

| Issue Type | Contact |
|------------|---------|
| Technical Support | [Email/Phone] |
| System Administrator | [Email/Phone] |
| Emergency | [Emergency Number] |
| Feedback | [Feedback Form] |

---

## 📚 Documentation Links

- **User Manual**: [docs/USER_MANUAL.md](USER_MANUAL.md)
- **Deployment Guide**: [docs/DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
- **Implementation Checklist**: [docs/IMPLEMENTATION_CHECKLIST.md](IMPLEMENTATION_CHECKLIST.md)
- **README**: [README.md](../README.md)

---

## 🎯 Key Features Summary

✅ Secure authentication with JWT  
✅ Outbreak submission with validation  
✅ Interactive map location picker  
✅ Health alert creation system  
✅ Real-time statistics dashboard  
✅ CSV import/export  
✅ Automated backups  
✅ Mobile responsive  
✅ Production-ready  
✅ Complete documentation  

---

## 📝 Field Limits

| Field | Min | Max | Type |
|-------|-----|-----|------|
| Password | - | - | Exact match |
| Patient Count | 1 | 10,000 | Integer |
| Disease Type | 2 | 100 | String |
| Description | 0 | 500 | Text |
| Alert Title | 5 | 100 | String |
| Alert Message | 10 | 500 | Text |
| Radius | 0 | 1,000 | Float (km) |
| Expiry Hours | 1 | 720 | Integer |

---

## 🗓️ Version Info

**Current Version**: 1.0.0  
**Release Date**: January 30, 2025  
**Status**: Production Ready  
**Last Updated**: January 30, 2025  

---

## ⚡ Quick Tips

1. **Use Quick Location buttons** for faster map navigation
2. **Fill description** for better data quality
3. **Check coordinates** before submitting
4. **Backup regularly** with automated script
5. **Monitor statistics** in View tab
6. **Logout** when finished for security
7. **Report bugs** to admin immediately
8. **Keep password** confidential
9. **Review data** before deleting
10. **Use appropriate severity** levels

---

## 🎓 Best Practices

**Data Submission**:
- Be accurate with patient counts
- Use exact locations
- Provide detailed descriptions
- Choose appropriate severity
- Submit promptly

**Alert Creation**:
- Clear, specific titles
- Detailed messages
- Actionable advice
- Appropriate urgency
- Correct expiry time

**Security**:
- Never share password publicly
- Logout when done
- Use secure connection
- Don't leave unattended
- Report suspicious activity

---

**Need more help?** Check the full [User Manual](USER_MANUAL.md) or [Deployment Guide](DEPLOYMENT_GUIDE.md)
